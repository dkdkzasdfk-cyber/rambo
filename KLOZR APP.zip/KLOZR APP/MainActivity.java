package com.klozr.keyboard;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    
    private List<String> sentences = new ArrayList<>();
    private SentencesAdapter adapter;
    private SharedPreferences prefs;
    private Button btnStart, btnStop;
    private TextView statusText;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        prefs = getSharedPreferences("KlozrPrefs", MODE_PRIVATE);
        loadSentences();
        
        // واجهة التطبيق
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);
        layout.setBackgroundColor(0xFF0a0f1a);
        
        // عنوان
        TextView title = new TextView(this);
        title.setText("KLOZR KEYBOARD");
        title.setTextSize(32);
        title.setTextColor(0xFF4488ff);
        title.setGravity(1);
        title.setPadding(0, 0, 0, 32);
        layout.addView(title);
        
        // زر تفعيل خدمة الوصول
        Button btnEnable = new Button(this);
        btnEnable.setText("🔓 تفعيل خدمة الوصول");
        btnEnable.setBackgroundColor(0xFF2a6f2a);
        btnEnable.setTextColor(0xFFFFFFFF);
        btnEnable.setPadding(16, 16, 16, 16);
        btnEnable.setOnClickListener(v -> openAccessibilitySettings());
        layout.addView(btnEnable);
        
        // حالة الخدمة
        statusText = new TextView(this);
        statusText.setText("⏳ جاري التحقق...");
        statusText.setTextColor(0xFF88aaff);
        statusText.setPadding(0, 16, 0, 16);
        layout.addView(statusText);
        
        // إضافة جملة
        LinearLayout addLayout = new LinearLayout(this);
        addLayout.setOrientation(LinearLayout.HORIZONTAL);
        addLayout.setPadding(0, 16, 0, 16);
        
        EditText inputSentence = new EditText(this);
        inputSentence.setHint("اكتب جملة جديدة...");
        inputSentence.setTextColor(0xFFFFFFFF);
        inputSentence.setHintTextColor(0xFF888888);
        inputSentence.setBackgroundColor(0xFF1a1f2a);
        inputSentence.setPadding(16, 12, 16, 12);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        inputParams.setMargins(0, 0, 16, 0);
        inputSentence.setLayoutParams(inputParams);
        addLayout.addView(inputSentence);
        
        Button btnAdd = new Button(this);
        btnAdd.setText("➕");
        btnAdd.setBackgroundColor(0xFF2a6f2a);
        btnAdd.setTextColor(0xFFFFFFFF);
        btnAdd.setPadding(24, 12, 24, 12);
        btnAdd.setOnClickListener(v -> {
            String text = inputSentence.getText().toString().trim();
            if (!text.isEmpty()) {
                sentences.add(text);
                saveSentences();
                adapter.notifyDataSetChanged();
                inputSentence.setText("");
                Toast.makeText(this, "تمت الإضافة", Toast.LENGTH_SHORT).show();
            }
        });
        addLayout.addView(btnAdd);
        layout.addView(addLayout);
        
        // قائمة الجمل
        RecyclerView recyclerView = new RecyclerView(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SentencesAdapter(sentences, pos -> {
            sentences.remove(pos);
            saveSentences();
            adapter.notifyDataSetChanged();
        });
        recyclerView.setAdapter(adapter);
        RecyclerView.LayoutParams rvParams = new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT,
            400
        );
        recyclerView.setLayoutParams(rvParams);
        layout.addView(recyclerView);
        
        // أزرار التحكم
        LinearLayout buttonsLayout = new LinearLayout(this);
        buttonsLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonsLayout.setPadding(0, 16, 0, 0);
        
        btnStart = new Button(this);
        btnStart.setText("▶ START");
        btnStart.setBackgroundColor(0xFF2277ff);
        btnStart.setTextColor(0xFFFFFFFF);
        btnStart.setPadding(24, 16, 24, 16);
        LinearLayout.LayoutParams startParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        startParams.setMargins(0, 0, 16, 0);
        btnStart.setLayoutParams(startParams);
        btnStart.setOnClickListener(v -> {
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "⚠️ يرجى تفعيل خدمة الوصول أولاً", Toast.LENGTH_LONG).show();
                openAccessibilitySettings();
                return;
            }
            if (sentences.isEmpty()) {
                Toast.makeText(this, "⚠️ أضف جمل أولاً", Toast.LENGTH_LONG).show();
                return;
            }
            saveSentencesToService();
            Toast.makeText(this, "✅ تم البدء - اذهب إلى أي تطبيق واكتب", Toast.LENGTH_LONG).show();
        });
        buttonsLayout.addView(btnStart);
        
        btnStop = new Button(this);
        btnStop.setText("⏹ STOP");
        btnStop.setBackgroundColor(0xFFff3355);
        btnStop.setTextColor(0xFFFFFFFF);
        btnStop.setPadding(24, 16, 24, 16);
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        btnStop.setLayoutParams(stopParams);
        btnStop.setOnClickListener(v -> stopServiceTyping());
        buttonsLayout.addView(btnStop);
        
        layout.addView(buttonsLayout);
        
        // حقوق الملكية
        TextView footer = new TextView(this);
        footer.setText("© 2024 KLOZR | by .7ki. | @Fenix");
        footer.setTextSize(10);
        footer.setTextColor(0xFF446688);
        footer.setGravity(1);
        footer.setPadding(0, 32, 0, 0);
        layout.addView(footer);
        
        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(layout);
        setContentView(scrollView);
        
        checkAccessibilityStatus();
    }
    
    private void checkAccessibilityStatus() {
        boolean enabled = isAccessibilityEnabled();
        if (enabled) {
            statusText.setText("✅ خدمة الوصول مفعلة | جاهز للعمل");
            statusText.setTextColor(0xFF44ff88);
        } else {
            statusText.setText("❌ خدمة الوصول غير مفعلة | اضغط على الزر أعلاه");
            statusText.setTextColor(0xFFff6688);
        }
    }
    
    private boolean isAccessibilityEnabled() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> services = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo service : services) {
            if (service.getResolveInfo().serviceInfo.packageName.equals(getPackageName())) {
                return true;
            }
        }
        return false;
    }
    
    private void openAccessibilitySettings() {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        startActivity(intent);
    }
    
    private void saveSentencesToService() {
        StringBuilder sb = new StringBuilder();
        for (String s : sentences) {
            sb.append(s).append("\n");
        }
        prefs.edit().putString("sentences", sb.toString()).apply();
        prefs.edit().putBoolean("should_type", true).apply();
    }
    
    private void stopServiceTyping() {
        prefs.edit().putBoolean("should_type", false).apply();
        Toast.makeText(this, "🛑 تم الإيقاف", Toast.LENGTH_SHORT).show();
    }
    
    private void loadSentences() {
        String saved = prefs.getString("sentences", "");
        sentences.clear();
        if (!saved.isEmpty()) {
            String[] lines = saved.split("\n");
            for (String line : lines) {
                if (!line.trim().isEmpty()) {
                    sentences.add(line);
                }
            }
        }
        if (sentences.isEmpty()) {
            sentences.add("مرحباً بك في تطبيق KLOZR");
            sentences.add("هذا كيبورد يكتب تلقائياً");
            sentences.add("يمكنك إضافة جمل جديدة");
        }
    }
    
    private void saveSentences() {
        StringBuilder sb = new StringBuilder();
        for (String s : sentences) {
            sb.append(s).append("\n");
        }
        prefs.edit().putString("sentences", sb.toString()).apply();
    }
    
    class SentencesAdapter extends RecyclerView.Adapter<SentencesAdapter.ViewHolder> {
        private List<String> data;
        private OnDeleteListener listener;
        
        interface OnDeleteListener {
            void onDelete(int position);
        }
        
        SentencesAdapter(List<String> data, OnDeleteListener listener) {
            this.data = data;
            this.listener = listener;
        }
        
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LinearLayout layout = new LinearLayout(parent.getContext());
            layout.setOrientation(LinearLayout.HORIZONTAL);
            layout.setPadding(16, 12, 16, 12);
            layout.setBackgroundColor(0xFF11161f);
            
            TextView text = new TextView(parent.getContext());
            text.setTextColor(0xFFdddddd);
            text.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            layout.addView(text);
            
            Button deleteBtn = new Button(parent.getContext());
            deleteBtn.setText("X");
            deleteBtn.setBackgroundColor(0xFF5a2a2a);
            deleteBtn.setTextColor(0xFFFFFFFF);
            deleteBtn.setPadding(16, 8, 16, 8);
            layout.addView(deleteBtn);
            
            ViewHolder holder = new ViewHolder(layout, text, deleteBtn);
            deleteBtn.setOnClickListener(v -> {
                int pos = holder.getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) {
                    listener.onDelete(pos);
                }
            });
            return holder;
        }
        
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            holder.text.setText(data.get(position));
        }
        
        @Override
        public int getItemCount() {
            return data.size();
        }
        
        class ViewHolder extends RecyclerView.ViewHolder {
            TextView text;
            ViewHolder(View itemView, TextView text, Button deleteBtn) {
                super(itemView);
                this.text = text;
            }
        }
    }
}
