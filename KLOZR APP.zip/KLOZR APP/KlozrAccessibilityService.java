package com.klozr.keyboard;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;

public class KlozrAccessibilityService extends AccessibilityService {
    
    private List<String> sentences = new ArrayList<>();
    private int currentIndex = 0;
    private int currentCharIndex = 0;
    private boolean isTyping = false;
    private String currentText = "";
    private android.os.Handler handler = new android.os.Handler();
    
    @Override
    public void onCreate() {
        super.onCreate();
        loadSentences();
    }
    
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        SharedPreferences prefs = getSharedPreferences("KlozrPrefs", MODE_PRIVATE);
        boolean shouldType = prefs.getBoolean("should_type", false);
        
        if (shouldType && !isTyping) {
            loadSentences();
            if (!sentences.isEmpty()) {
                isTyping = true;
                currentIndex = 0;
                currentCharIndex = 0;
                currentText = "";
                startTyping();
            }
        } else if (!shouldType && isTyping) {
            isTyping = false;
            handler.removeCallbacksAndMessages(null);
        }
    }
    
    private void loadSentences() {
        SharedPreferences prefs = getSharedPreferences("KlozrPrefs", MODE_PRIVATE);
        String saved = prefs.getString("sentences", "");
        sentences.clear();
        if (!saved.isEmpty()) {
            String[] lines = saved.split("\n");
            for (String line : lines) {
                if (!line.trim().isEmpty()) {
                    sentences.add(line);
                }
            }
        }
    }
    
    private void startTyping() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (!isTyping || currentIndex >= sentences.size()) {
                    isTyping = false;
                    return;
                }
                
                String sentence = sentences.get(currentIndex);
                AccessibilityNodeInfo root = getRootInActiveWindow();
                if (root != null) {
                    List<AccessibilityNodeInfo> editableNodes = root.findAccessibilityNodeInfosByViewId("android:id/edit");
                    if (editableNodes.isEmpty()) {
                        editableNodes = root.findAccessibilityNodeInfosByText("");
                        for (int i = 0; i < editableNodes.size(); i++) {
                            if (editableNodes.get(i).isEditable()) {
                                editableNodes = java.util.Collections.singletonList(editableNodes.get(i));
                                break;
                            }
                        }
                    }
                    
                    if (!editableNodes.isEmpty()) {
                        AccessibilityNodeInfo editText = editableNodes.get(0);
                        if (currentCharIndex < sentence.length()) {
                            char c = sentence.charAt(currentCharIndex);
                            String toType = String.valueOf(c);
                            Bundle arguments = new Bundle();
                            arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, currentText + toType);
                            editText.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);
                            currentText += toType;
                            currentCharIndex++;
                            handler.postDelayed(this, 1); // 0.001ms بين كل حرف
                        } else {
                            // انتهت الجملة، اضغط Enter
                            Bundle arguments = new Bundle();
                            arguments.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END, currentText.length());
                            editText.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, arguments);
                            
                            // محاكاة زر Enter
                            editText.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                            
                            currentIndex++;
                            currentCharIndex = 0;
                            currentText = "";
                            handler.postDelayed(this, 50);
                        }
                    } else {
                        handler.postDelayed(this, 100);
                    }
                } else {
                    handler.postDelayed(this, 100);
                }
                root.recycle();
            }
        });
    }
    
    @Override
    public void onInterrupt() {
        isTyping = false;
        handler.removeCallbacksAndMessages(null);
    }
}